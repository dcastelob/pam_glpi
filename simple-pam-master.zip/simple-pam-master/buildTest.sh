#!/bin/bash

g++ -o pam_test src/test.c -lpam -lpam_misc
